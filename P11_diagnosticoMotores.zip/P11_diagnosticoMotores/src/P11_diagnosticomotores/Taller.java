package P11_diagnosticomotores;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Taller {
    public static void main(String[] args) {
        //VARIABLES LOCALES
        
        //CAPTURAR DATOS
        
        //LISTAR DATOS
        System.out.println();
        System.out.println();
        System.out.println();
    }
}
