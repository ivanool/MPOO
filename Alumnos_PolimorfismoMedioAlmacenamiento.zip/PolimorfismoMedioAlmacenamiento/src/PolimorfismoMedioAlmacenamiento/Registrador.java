package PolimorfismoMedioAlmacenamiento;

public class Registrador {
    public static void main(String[] args) {
        Disco almacenDisco;
        Usb almacenUsb;
        Impresora almacenImpresora;
        Red almacenRed1, almacenRed2;
        
        //CREANDO OBJETOS
        System.out.println("Creando el objeto Disco:");
        almacenDisco = new Disco();
        System.out.println("Creando el objeto Usb:");
        almacenUsb= new Usb();  
        System.out.println("Creando el objeto Impresora:");
        almacenImpresora = new Impresora();
        System.out.println("Creando el objeto Red:");
        almacenRed1 = new Red("laboratorio");
        almacenRed2 = new Red();

        System.out.println("GRABANDO...\n-----------------------");
        System.out.println("GRABANDO a USB:");
        almacenUsb.grabar();
        System.out.println("GRABANDO a DISCO:");
        almacenDisco.grabar();
        System.out.println("GRABANDO a RED:");
        almacenRed1.grabar();
        System.out.println("GRABANDO a IMPRESORA:");
        almacenImpresora.grabar();
    }   
}
