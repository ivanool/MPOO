package PolimorfismoMedioAlmacenamiento;
public class MedioAlmacenamiento {
    MedioAlmacenamiento(){
      System.out.println("\tIniciando un objeto de tipo MedioAlmacenamiento");
   }
    public void grabar(){ }
}
