package PolimorfismoMedioAlmacenamiento;
public class MedioLocal extends EntradaSalida {
   MedioLocal(){
       System.out.println("\tSe creo un objeto de tipo MedioLocal");
   }
   @Override
   public void grabar(){
       System.out.println("\tPreparando dispositivo MedioLocal para grabar");
   }
}
