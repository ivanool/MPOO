package PolimorfismoMedioAlmacenamiento;

public class Impresora extends MedioAlmacenamiento{
    Impresora(){
       System.out.println("\tSe creo un objeto de tipo Impresora");
    }
    public void grabar(){
       System.out.println("\tImprimiendo Documento ###");
    }
}
