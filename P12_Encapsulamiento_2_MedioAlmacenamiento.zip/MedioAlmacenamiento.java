package Encapsulamiento_2_MedioAlmacenamiento;
public class MedioAlmacenamiento {
    MedioAlmacenamiento(){
      System.out.println("\tIniciando un objeto de tipo MedioAlmacenamiento");
   }
    void grabar() {
        
    }
}
