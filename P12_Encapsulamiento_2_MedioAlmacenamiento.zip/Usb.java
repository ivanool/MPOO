package Encapsulamiento_2_MedioAlmacenamiento;
public class Usb extends MedioLocal{
    Usb(){
       System.out.println("\tSe creo un objeto de tipo Usb");
    }
    void grabar(){
       System.out.println("\tGrabando a una Usb * * *");
    }
}
