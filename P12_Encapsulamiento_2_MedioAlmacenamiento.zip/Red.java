package Encapsulamiento_2_MedioAlmacenamiento;

public class Red extends EntradaSalida{
    Red(String nombre){
       System.out.println("\tSe creo un objeto de tipo Red, con nombre -->"+nombre);
    }
    Red(){
       System.out.println("\tSe creo un objeto de tipo Red");
    }
}
